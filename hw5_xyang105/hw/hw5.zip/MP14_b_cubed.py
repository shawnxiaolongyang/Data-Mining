def norm(data):
    normalized_data = [[0,0,0]for i in range(len(data))]
    data_x = []
    data_y = []
    data_category = []
    for i in range(len(data)):
        data_x.append(data[i][0])
        data_y.append(data[i][1])
        data_category.append(data[i][2])
    for i in range(len(data)):
        normalized_data[i][0] = round(float((data[i][0]-min(data_x)))/(max(data_x)-min(data_x)),4)
        normalized_data[i][1] = round(float((data[i][1]-min(data_y)))/(max(data_y)-min(data_y)),4)
        normalized_data[i][2] = data_category[i]
    return normalized_data

f = open("truth.txt", "r")

content = f.read()


cells = content.split("\n")


cells.pop(0),cells.pop(0),cells.pop(-1)

f.close()


data = [[0,0,0] for i in range(len(cells))]
for i in range(len(cells)):
    data[i][0] = float(cells[i].strip(' ').split(',')[0])
    data[i][1] = float(cells[i].strip(' ').split(',')[1])
    data[i][2] = float(cells[i].strip(' ').split(',')[2])
    

normalized_data = norm(data)



def b_cube(filename):
    text = filename.read()
    cells = text.split("\n")
    cells.pop(0),cells.pop(0),cells.pop(-1)
    dat = [[0,0,0] for i in range(len(cells))]
    for i in range(len(cells)):
        dat[i][0] = float(cells[i].strip(' ').split(',')[0])
        dat[i][1] = float(cells[i].strip(' ').split(',')[1])
        dat[i][2] = float(cells[i].strip(' ').split(',')[2])
    data2 = [[0,0,0,0] for i in range(len(data))]
    for ii in range(len(dat)):
        for iii in range(len(normalized_data)):
            if dat[ii][0] == normalized_data[iii][0]:
                if dat[ii][1] == normalized_data[iii][1]:
                    data2[ii][0] = dat[ii][0]
                    data2[ii][1] = dat[ii][1]
                    data2[ii][2] = dat[ii][2]
                    data2[ii][3] = normalized_data[iii][2]
    TRuePossitive = [[0,0,0,0]for i in range(4)]
    Possitive = [0,0,0,0]
    TRue = [0,0,0,0]
    for n in range(4):
        for i in data2:
            for m in range(4):
                if i[2] ==n+1:
                    if i[3] ==m+1:
                        TRuePossitive[n][m] += 1

        for i in data2:
            if i[2] ==n+1:
                Possitive[n] += 1

        for i in data2:
            if i[3] ==n+1:
                TRue[n] += 1
    return TRuePossitive,Possitive,TRue

f1 = open("step1.txt", "r")
TRuePossitive,Possitive,TRue = b_cube(f1)
print TRuePossitive,Possitive,TRue
Precision1 =(float(1909)**2/3185+float(4270)**2/6525)/sum([1909,4270])
Recall1 = (float(1909)**2/3333+float(4270)**2/4270)/sum([1909,4270])
print Precision1,Recall1

f2a= open("step2a.txt", "r")
TRuePossitive,Possitive,TRue = b_cube(f2a)
print TRuePossitive,Possitive,TRue
Precision2 =(float(1979)**2/3542+float(4270)**2/6168)/sum([1979,4270])
Recall2 = (float(1979)**2/3542+float(4270)**2/4270)/sum([1979,4270])
print Precision2,Recall2

f2b = open("step2b.txt", "r")
TRuePossitive,Possitive,TRue = b_cube(f2b)
print TRuePossitive,Possitive,TRue
Precision3 = (float(1034)**2/3508+float(4270)**2/4849+float(1353)**2/1353)/sum([1034,4270,1353])
Recall3 = (float(1034)**2/1034+float(4270)**2/4270+float(1353)**2/3333)/sum([1034,4270,1353])
print Precision3,Recall3
