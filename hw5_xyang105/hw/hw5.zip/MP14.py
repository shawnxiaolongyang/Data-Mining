
from random import randint
import itertools 

def norm(data):
    d_x = []
    d_y = []
    data_norm = [[0,0]for i in range(len(data))]
    
    for i in range(len(data)):
        d_x.append(data[i][0])
        d_y.append(data[i][1])
    for i in range(len(data)):
        data_norm[i][0] = round(float((data[i][0]-min(d_x)))/(max(d_x)-min(d_x)),4)
        data_norm[i][1] = round(float((data[i][1]-min(d_y)))/(max(d_y)-min(d_y)),4)
    return data_norm


def distant(point1,point2):
    distance = 0
    for i in range(len(point1)):
        distance += (point1[i]-point2[i])**2
    return round(float(distance)**0.5,3)



def centroid(cell):
    center_x = 0
    center_y = 0
    for i in cell:
        center_x += i[0]
        center_y += i[1]
    center = [round(float(center_x)/len(cell),4), round(float(center_y)/len(cell),4)]
    return center


def SSE(cells,center,k):
    sum_error = 0
    for i in range(k):
        for cell in cells[k-i-1]:
            sum_error += (distant(center[i],cell))**2
    return sum_error         

def random_value(data,center):
    value = randint(0,len(data)-1)
    random_value = data[value]
    center.append(random_value)
    data.pop(value)
    return data,center

def k_meanspp(center):
    
    value = normalized_data[randint(0,len(data)-1)]
    count = 0

    for iii in center:
        if distant(value,iii) > 0.2:
            count += 0
        else:
            count += 1
    if count == 0:
        return value
    else:
        return None


def random_generator(center):
    for i in range(100):
        value = k_meanspp(center)
        if value:
            return value
            break


def cluster(data,k,center,sum_error):
    cells = [[]for i in range(k)]       
    distance = [[0]*k for i in range(len(data))]
    
    for i in range(len(data)):
        for ii in range(k):
            
            distance[i][ii] =  distant(data[i],center[ii])
    for i in range(len(data)):
        for ii in range(k):
            if distant(data[i],center[ii]) == max(distance[i]):
                count = 0
                if ii > 0:
                    for iii in range(ii):
                        if data[i] not in cells[iii]:
                            count+= 0
                        else:
                            count+= 1
                if count== 0:
                    cells[ii].append(data[i])
    n = 0
    center_2_step_before = [[0,0]for i in range(k)]
    
    if sum_error !=0:
        for i in range(k):
            for ii in range(i+1,k):
                
                if center[ii] == center[i]:
                    center[ii] = random_generator(center)
                    print "replace one point"
            
            if center[i] ==[0,0]:
                center[i] = random_generator(center)
                print "add one new point"
            
            if len(cells[k-i-1])==0:
                center[i] = random_generator(center)
                         
            else:
                center_2_step_before[i] = centroid(cells[k-i-1])
                
        print center,sum_error,center_2_step_before,SSE(cells,center_2_step_before,k)
                
        for i in range(len(center)):
            if center[i] == [0,0]:
                n = 1
                center[i] = random_generator(center)
                
        if n == 0:
            if SSE(cells,center_2_step_before,k)<sum_error:
                center = center_2_step_before
            else:
                n = 1
        
        
                
        
    sum_error = SSE(cells,center,k)
    return center,cells,sum_error,n


def find_result(cells,k):
    results = []
    for i in range(k):
        cell = []
        for ii in range(len(cells[i])):
            cell=cells[i][ii]
            cell.append(i)
            results.append(cell)
    return results


def iterate(data,k):
    new_data = []
    for i in data:
        new_data.append(i)
    center = []
    
    for i in range(k):
        new_data,center = random_value(new_data,center)
    
    
    n = 0
    results = []
    sum_error = 0
    for i in range(200):
        print i
        if i == 199:
            center,cells,sum_error,n = cluster(data,k,center,sum_error)
            results = find_result(cells,k)
            return results,sum_error
        elif n == 0:
            center,cells,sum_error,n = cluster(data,k,center,sum_error)
            print "go on"
        else:
            center,cells,sum_error,n = cluster(data,k,center,sum_error)
            print "find optimization"
            results = find_result(cells,k)
            return results,sum_error
            break

def evaluate(data,k):
    normalized_data = norm(data)
    results,sum_error = iterate(normalized_data,k)
    return results

def output_file(path,results):
        file = open(path, 'w')
        string = str(len(data))+"\n"
        for i in results:
            for ii in range(len(i)):
                if ii != 2:
                    string += str(i[ii]) + ','
                if ii ==2 :
                    a = i[ii]+1
                    string += str(a) + ','
            string += '\n'
        file.write(string)
        file.close()

f = open("data.txt", "r")

content = f.read()

cells = content.split("\n")

cells.pop(0),cells.pop(-1)

data = [[0,0] for i in range(len(cells))]
for i in range(len(cells)):
    data[i][0] = float(cells[i].strip(' ').split(',')[0])
    data[i][1] = float(cells[i].strip(' ').split(',')[1])

f.close()

normalized_data = norm(data)

results = [[]for i in range(3)]

results[0] = evaluate(data,4)

results[1] = evaluate(data,3)

results[2] = evaluate(data,5)

output_file('step1.txt',results[0])
output_file('step2a.txt',results[1])
output_file('step2b.txt',results[2])






