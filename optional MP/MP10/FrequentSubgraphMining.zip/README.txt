INSTALLATION: 
To install the subgraphMining package, follow these steps:
1. First navigate to the directory that it resides in.
2. If the iGraph package is not installed, install it by calling "install.packages('igraph')" without the double quotes in R. 
3. In a command prompt, type "R CMD INSTALL subgraphMining_1.0.tar.gz" without the quotes. 