scatter([-10,-6,-4,-3,0,1,3,3,3,8],[12,8,6,5,2,1,-1,-1,-1,-6])
hold on
lsline;
text(0,8,'Correlation = -1');
